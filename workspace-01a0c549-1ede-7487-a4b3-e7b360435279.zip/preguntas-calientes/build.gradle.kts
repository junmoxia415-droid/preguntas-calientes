// Top-level build file where you can add configuration options common to all sub-projects/modules.
// Desarrollado por: Airien Yolexis Rojas Roque - Studio Lexair
plugins {
    id("com.android.application") version "8.2.0" apply false
    id("org.jetbrains.kotlin.android") version "1.9.22" apply false
}
